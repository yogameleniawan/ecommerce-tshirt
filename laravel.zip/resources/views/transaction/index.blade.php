<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Color</th>
                <th>Price</th>
                <th>Image</th>
                <th>action</th>
            </tr>
        </thead>
        <tbody>
            @foreach($data as $d)
            <tr>
                <td>{{$d->id}}</td>
                <td>{{$d->name}}</td>
                <td>{{$d->color}}</td>
                <td>{{$d->price}}</td>
                <td>
                    <img src="{{url('storage')}}/{{$d->image}}" style="width:5%">
                </td>
                <td>
                    <a class="btn btn-primary" href="/shop/{{$d->id}}/order">Beli</a>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</body>

</html>