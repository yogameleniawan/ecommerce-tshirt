<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Kaos | Order</title>
    <link rel="icon" href="img/icon/kaos-icon.png" type="image/x-icon">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
    <!-- Google Fonts Roboto -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="<?php echo e(url('css/bootstrap.min.css')); ?>">
    <!-- Material Design Bootstrap -->
    <link rel="stylesheet" href="<?php echo e(url('css/mdb.min.css')); ?>">
    <!-- Your custom styles (optional) -->
    <link rel="stylesheet" href="<?php echo e(url('css/style.css')); ?>">
</head>

</head>
<style>
    html,
    body,
    header,
    .view {
        height: 100%;
    }

    body {
        overflow-x: hidden;
    }
</style>

<body style="background-color: #292929;">

    <!-- Start your project here-->
    <!--Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark ">
        <a class="navbar-brand" href="/home"><img src="/img/icon/kaos.png" alt="" style="width:130px"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-555" aria-controls="navbarSupportedContent-555" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent-555">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item ">
                    <a class="nav-link" href="/home">Home
                        <span class="sr-only">(current)</span>
                    </a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="/shop">Shop</a>
                </li>
            </ul>
            <?php if(empty(Auth::user())): ?>
            <ul class="navbar-nav ml-auto nav-flex-icons">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>">Login/Register</a>
                </li>
            </ul>
            <?php endif; ?>
            <?php if(!empty(Auth::user())): ?>
            <ul class="navbar-nav ml-auto nav-flex-icons">
                <li class="nav-item">
                    <a href="/cart" class="nav-link waves-effect waves-light">
                        <i class="fas fa-shopping-bag"></i>
                        <span class="badge badge-danger badge-counter">
                            <?php echo e($cart); ?>

                        </span>
                    </a>
                </li>
                <li class="nav-item avatar dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-55" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="<?php echo e(url('storage')); ?>/<?php echo e(Auth::user()->image_profile); ?>" class="rounded-circle z-depth-0" alt="avatar image" style="width:30px;">
                    </a>
                    <div class="dropdown-menu dropdown-menu-lg-right dropdown-secondary" aria-labelledby="navbarDropdownMenuLink-55">
                        <a class="dropdown-item" href="/user/profile">Account Info</a>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Log out</a>
                    </div>
                </li>
            </ul>
            <?php endif; ?>
        </div>
    </nav>
    <div class="row" style="padding-left: 50px;padding-right:50px;padding-top:60px">
        <div class="col-md-6">

            <div class="text-center border border-light p-5" style="background-color:white">
                <!-- Card image -->
                <img src="<?php echo e(url('storage')); ?>/<?php echo e($data->image); ?>" alt="" style="width:300px;">

                <!-- Card content -->
                <div class="card-body">

                    <!-- Title -->
                    <h4 class="card-title"><b><?php echo e($data->name); ?></b></h4>
                    <h4 class="card-title">Rp. <?php echo e($data->price); ?></h4>
                    <!-- Text -->
                    <p>Color : <?php echo e($data->color); ?></p>
                    <table align="center" style="margin-bottom:10px">
                        <tr>
                            <td style="padding-right: 20px;">
                                <p class="card-text">
                                    <b>Material :</b>
                                    <br>
                                    - Suede fabric<br>
                                    - Despo furing <br>
                                    - Ykk Zipper <br>
                                    - Casmilon Rib <br>
                                    - Inside Pocket <br>
                                </p>
                            </td>
                            <td>
                                <p class="card-text">
                                    <b>Panjang x Lebar dada (cm) :</b>
                                    <br>
                                    S = 62 x 50<br>
                                    M = 65 x 53 <br>
                                    L = 67 x 56<br>
                                    XL = 70 x 59<br>
                                    XXL = 73 x 62 <br>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <!-- Card -->
            <div class="card">



            </div>
            <!-- Card -->
        </div>
        <div class="col-md-6">
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
            <form class="text-center border border-light p-5" action="<?php echo e(route('home.store')); ?>" method="POST" enctype="multipart/form-data" style="background-color:white">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="iduser" value="<?php echo e(Auth::user()->id); ?>">
                <input type="hidden" name="nameitem" value="<?php echo e($data->name); ?>">
                <input type="hidden" name="iditem" value="<?php echo e($data->id); ?>">
                <input type="hidden" name="price" value="<?php echo e($data->price); ?>">
                <!-- Name -->
                <h4 style="padding-bottom: 30px;"><b>Shoping Cart</b></h4>
                <label for="buyer">Buyer's Name</label>
                <input type="text" name="buyer" id="buyer" class="form-control mb-4 <?php $__errorArgs = ['buyer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required autocomplete="buyer" autofocus>
                <?php $__errorArgs = ['buyer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <!-- Address -->
                <label for="address">Address</label>
                <input type="text" name="address" id="address" class="form-control mb-4 <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required autocomplete="address" autofocus>
                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <!-- Phone -->
                <label for="phone">Phone Number</label>
                <input type="text" name="phone" id="phone" class="form-control mb-4 <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required autocomplete="phone" autofocus>
                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <!-- Size -->
                <label>Size</label>
                <select class="browser-default custom-select" name="size">
                    <option disabled selected>Choose Size</option>
                    <option name="s" value="S">S</option>
                    <option name="m" value="M">M</option>
                    <option name="l" value="L">L</option>
                    <option name="xl" value="XL">XL</option>
                    <option name="xxl" value="XXL">XXL</option>
                </select>
                <label for="qty" style="padding-top:25px">Qty</label>
                <input type="number" name="qty" id="qty" class="form-control mb-4 <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required autocomplete="qty" autofocus>
                <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <!-- Send button -->
                <button class="btn btn-dark btn-block" type="submit">Add to Cart</button>
                <p style="padding-bottom: 0px;"></p>
            </form>
        </div>
    </div>

    <!--/.Navbar -->
    <!-- End your project here-->

    <!-- jQuery -->
    <script type="text/javascript" src="<?php echo e(url('js/jquery.min.js')); ?>"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="<?php echo e(url('js/popper.min.js')); ?>"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="<?php echo e(url('js/mdb.min.js')); ?>"></script>
    <!-- Your custom scripts (optional) -->


</body>

</html><?php /**PATH E:\MI\Semester 3\Web Lanjut\Project\web\resources\views/transaction/order.blade.php ENDPATH**/ ?>