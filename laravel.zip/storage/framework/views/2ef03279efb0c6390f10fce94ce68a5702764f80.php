<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Color</th>
                <th>Price</th>
                <th>Image</th>
                <th>action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($d->id); ?></td>
                <td><?php echo e($d->name); ?></td>
                <td><?php echo e($d->color); ?></td>
                <td><?php echo e($d->price); ?></td>
                <td>
                    <img src="<?php echo e(url('storage')); ?>/<?php echo e($d->image); ?>" style="width:5%">
                </td>
                <td>
                    <a class="btn btn-primary" href="/shop/<?php echo e($d->id); ?>/order">Beli</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>

</html><?php /**PATH E:\MI\Semester 3\Web Lanjut\Project\web\resources\views/transaction/index.blade.php ENDPATH**/ ?>